package com.example.soccerstats.util;

public class TopTeams {

    /* LA LIGA */
    public static final String REAL_MADRID = "real_madrid";
    public static final String REAL_MADRID_ID = "fw3ok0fty95tz0ydspi2g5yzghm5exdj";

    public static final String BARCELONA = "barcellona";
    public static final String BARCELONA_ID = "fe6e0zt76gaejrbjuq662ayqvxln4bmh";

    public static final String ATLETICO_MADRID = "atl_madrid";
    public static final String ATLETICO_MADRID_ID = "uskk92ojo4eb2qlfaodhsfn1ptnquegi";

    /* PREMIER LEAGUE */
    public static final String ARSENAL = "arsenal";
    public static final String ARSENAL_ID = "zymx5xdh4knl5dwbcfv3kszge9d8brnw";

    public static final String CHELSEA = "chelsea";
    public static final String CHELSEA_ID = "blfamr89lxeyywtsraiqzq5p5zuz57i6";

    public static final String LIVERPOOL = "liverpool";
    public static final String LIVERPOOL_ID = "akppwaoizlxbsa66oupfkawevutbnjxp";

    public static final String MANCHESTER_CITY = "man_city";
    public static final String MAN_CITY_ID = "xy8xez8msmv4qucyabkhhk4rqbimnprx";

    public static final String MANCHESTER_UNITED = "man_united";
    public static final String MAN_UNITED_ID = "qtjxv9d71ntirsgpjbmeefda4gewdnd9";

    public static final String TOTTENHAM = "tottenham";
    public static final String TOTTENHAM_ID = "kdrhmjjufk8em0fqjtaltym29v4dwhhb";

    /* SERIE A */
    public static final String INTER = "inter";
    public static final String INTER_ID = "691f5aae875365927e918fe8cdf59de2";

    public static final String JUVENTUS = "juventus";
    public static final String JUVENTUS_ID = "a9ef824ba73b0a57e982df21467c3efc";

    public static final String MILAN = "milan";
    public static final String MILAN_ID = "a9ef824ba73b0a57e982df21467c3efc";

    public static final String NAPOLI = "napoli";
    public static final String NAPOLI_ID = "b7f5f1b1be693a8e1c5c3aa5aee2a05b";
}
