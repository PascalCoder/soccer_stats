package com.example.soccerstats.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

public class StandingsViewModel extends AndroidViewModel {
    public StandingsViewModel(@NonNull Application application) {
        super(application);
    }
}
